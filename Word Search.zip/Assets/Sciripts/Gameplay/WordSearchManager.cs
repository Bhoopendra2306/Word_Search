using System.Collections.Generic;
using UnityEngine;
using TMPro;
using System.Collections;
using UnityEngine.SceneManagement;

public class WordSearchManager : MonoBehaviour
{
    [Header("Grid Settings")]
    public int gridSize = 8;
    public GameObject gridCellPrefab;
    public Transform gridParent;

    [Header("Word List Display")]
    public TMP_Text wordListTextPrefab;
    public Transform wordListParent;

    [Header("Scoring UI")]
    public TMP_Text scoreText;
    public GameObject floatingTextPrefab;
    public Transform floatingTextParent;

    // Predefined sets of word lists
    private List<List<string>> allWordLists = new List<List<string>> {
        new List<string> { "APPLE", "BIRD", "CLOUD", "DREAM", "EARTH", "FIRE", "GOLD", "HOUSE" },
        new List<string> { "ISLAND", "JUMP", "KING", "LION", "MOON", "NIGHT", "OCEAN", "PEACE" },
        new List<string> { "QUIET", "RIVER", "SUN", "TREE", "UNITY", "VOICE", "WATER", "XENON" },
        new List<string> { "YOUNG", "ZEBRA", "ANGEL", "BLADE", "CHAIR", "DEEP", "EVERY", "FLOUR" },
        new List<string> { "GHOST", "HEART", "IRON", "JELLY", "KNIFE", "LIGHT", "MAGIC", "NOBLE" },
        new List<string> { "OPERA", "PRIZE", "QUEST", "RANGE", "SHINE", "THORN", "URBAN", "VIRAL" },
        new List<string> { "WIND", "XRAY", "YARN", "ZONE", "ALPHA", "BRAVE", "CRISP", "DANCE" },
        new List<string> { "EAGER", "FAITH", "GLORY", "HONEY", "IDEAL", "JOLLY", "KARMA", "LEMON" },
        new List<string> { "MANGO", "NINJA", "OLIVE", "PARTY", "QUACK", "ROBOT", "SMILE", "TIGER" },
        new List<string> { "UMBRELLA", "VIOLIN", "WHISPER", "XYLO", "YAWN", "ZIGZAG", "ARMOR", "BEACH" }
    };

    private List<string> wordList; // The selected word list for this round
    private GridCell[,] grid;
    private HashSet<string> placedWords = new HashSet<string>();
    public Dictionary<string, WordDisplay> wordDisplays = new Dictionary<string, WordDisplay>();

    private int score = 0;
    public TextMeshProUGUI ScoreAtGameOver;
    public GameObject gameOverPanel;

    void Start()
    {
        gameOverPanel.SetActive(false);
           // Select a random word list
           wordList = allWordLists[Random.Range(0, allWordLists.Count)];

        // Initialize grid
        grid = new GridCell[gridSize, gridSize];
        GenerateGrid();
        PlaceWords();
        FillEmptySpaces();

        UpdateScoreUI();

        Debug.Log("Selected Word Set: " + string.Join(", ", wordList));
    }

    void GenerateGrid()
    {
        for (int y = 0; y < gridSize; y++)
        {
            for (int x = 0; x < gridSize; x++)
            {
                GameObject cellObj = Instantiate(gridCellPrefab, gridParent);
                GridCell cell = cellObj.GetComponent<GridCell>();
                cell.SetCoordinates(x, y);
                grid[y, x] = cell;
            }
        }
    }

    void PlaceWords()
    {
        System.Array directions = new (int, int)[] {
        (1, 0), (0, 1), (1, 1),
        (-1, 0), (0, -1), (-1, -1),
        (1, -1), (-1, 1)
    };

        int wordsPlaced = 0;
        int maxAttemptsPerWord = 100;
        int maxTotalAttempts = 1000;
        int totalAttempts = 0;

        while (wordsPlaced < wordList.Count && totalAttempts < maxTotalAttempts)
        {
            string word = wordList[wordsPlaced].ToUpper();
            bool placed = false;

            for (int attempts = 0; attempts < maxAttemptsPerWord && !placed; attempts++)
            {
                totalAttempts++;
                var dir = ((int, int))directions.GetValue(Random.Range(0, directions.Length));
                int dx = dir.Item1;
                int dy = dir.Item2;

                int startX = Random.Range(0, gridSize);
                int startY = Random.Range(0, gridSize);

                int endX = startX + dx * (word.Length - 1);
                int endY = startY + dy * (word.Length - 1);

                if (endX < 0 || endX >= gridSize || endY < 0 || endY >= gridSize)
                    continue;

                bool canPlace = true;
                for (int i = 0; i < word.Length; i++)
                {
                    int x = startX + dx * i;
                    int y = startY + dy * i;
                    char current = grid[y, x].GetLetter();
                    if (current != '\0' && current != word[i])
                    {
                        canPlace = false;
                        break;
                    }
                }

                if (!canPlace)
                    continue;

                for (int i = 0; i < word.Length; i++)
                {
                    int x = startX + dx * i;
                    int y = startY + dy * i;
                    grid[y, x].SetLetter(word[i]);
                    grid[y, x].AddToWord(word);
                }

                placedWords.Add(word);

                TMP_Text wordText = Instantiate(wordListTextPrefab, wordListParent);
                WordDisplay display = wordText.gameObject.AddComponent<WordDisplay>();
                display.Setup(word);
                wordDisplays[word] = display;

                placed = true;
                wordsPlaced++;
            }

            if (!placed)
            {
                Debug.LogWarning($"Failed to place word: {word}");
                wordsPlaced++;
            }
        }

        if (placedWords.Count < wordList.Count)
        {
            Debug.LogWarning($"Only placed {placedWords.Count} out of {wordList.Count} words.");
        }
    }


    void FillEmptySpaces()
    {
        for (int y = 0; y < gridSize; y++)
        {
            for (int x = 0; x < gridSize; x++)
            {
                if (grid[y, x].GetLetter() == '\0')
                {
                    char randomChar = (char)Random.Range(65, 91); // A-Z
                    grid[y, x].SetLetter(randomChar);
                }
            }
        }
    }

    public bool IsWordInList(string word)
    {
        return placedWords.Contains(word.ToUpper());
    }

    public void WordFound(string word)
    {
        string upper = word.ToUpper();
        if (wordDisplays.ContainsKey(upper))
        {
            wordDisplays[upper].MarkFound();
        }

        score += 10;
        UpdateScoreUI();

        ShowFloatingText("+10");

        if(score >= 80)
        {
            ScoreAtGameOver.text = score.ToString();
            gameOverPanel.SetActive(true);
        }
    }

    public void ReloadScene()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);

    }

    void UpdateScoreUI()
    {
        if (scoreText != null)
        {
            scoreText.text = score.ToString();
        }
    }

    void ShowFloatingText(string text)
    {
        if (floatingTextPrefab != null && floatingTextParent != null && scoreText != null)
        {
            GameObject ft = Instantiate(floatingTextPrefab, floatingTextParent);
            TMP_Text tmp = ft.GetComponent<TMP_Text>();
            if (tmp != null)
            {
                tmp.text = text;
            }

            Vector3 startPos = ft.transform.position;
            Vector3 targetPos = scoreText.transform.position;

            StartCoroutine(MoveFloatingText(ft, startPos, targetPos));
        }
    }

    IEnumerator MoveFloatingText(GameObject floatingText, Vector3 startPos, Vector3 targetPos)
    {
        float moveSpeed = 1.5f;
        float timeElapsed = 0f;
        floatingText.transform.position = startPos;

        while (timeElapsed < 1f)
        {
            timeElapsed += Time.deltaTime * moveSpeed;
            floatingText.transform.position = Vector3.Lerp(startPos, targetPos, timeElapsed);
            yield return null;
        }
        Destroy(floatingText);
    }

    // NEW: Helper method to get the grid cell at the given (x, y) coordinates.
    // Returns null if the coordinates are outside the grid.
    public GridCell GetCell(int x, int y)
    {
        if (x >= 0 && x < gridSize && y >= 0 && y < gridSize)
        {
            return grid[y, x];
        }
        return null;
    }
}
