using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class HintManager : MonoBehaviour
{
    [Header("Hint System Settings")]
    public WordSearchManager wordSearchManager;       // Assign in Inspector
    public Button hintButton;                         // Assign the UI button
    public TMP_Text hintCounterText;                  // Assign TextMeshPro Text
    public int totalHints = 3;

    private int hintsUsed = 0;

    void Start()
    {
        if (hintButton != null)
            hintButton.onClick.AddListener(UseHint);
        else
            Debug.LogWarning("Hint button not assigned in HintManager.");

        UpdateHintCounterText();
    }

    public void UseHint()
    {
        if (hintsUsed >= totalHints)
        {
            Debug.Log("No hints remaining!");
            hintButton.interactable = false;
            return;
        }

        string hintWord = GetUnfoundWord();

        if (!string.IsNullOrEmpty(hintWord))
        {
            HighlightWord(hintWord);
            hintsUsed++;

            UpdateHintCounterText();

            if (hintsUsed >= totalHints && hintButton != null)
            {
                hintButton.interactable = false;
            }
        }
        else
        {
            Debug.Log("All words already found!");
        }
    }

    private void UpdateHintCounterText()
    {
        if (hintCounterText != null)
        {
            int hintsLeft = totalHints - hintsUsed;
            hintCounterText.text = hintsLeft.ToString();
        }
    }

    private string GetUnfoundWord()
    {
        foreach (var kvp in wordSearchManager.wordDisplays)
        {
            TMP_Text wordText = kvp.Value.GetComponent<TMP_Text>();
            if (wordText != null && wordText.color != Color.green)
            {
                return kvp.Key;
            }
        }
        return null;
    }

    private void HighlightWord(string word)
    {
        word = word.ToUpper();
        int gridSize = wordSearchManager.gridSize;
        GridCell[,] grid = GetGridFromManager();

        (int x, int y)[] directions = new (int, int)[]
        {
            (1, 0), (0, 1), (1, 1), (-1, 0), (0, -1), (-1, -1), (1, -1), (-1, 1)
        };

        for (int y = 0; y < gridSize; y++)
        {
            for (int x = 0; x < gridSize; x++)
            {
                foreach (var dir in directions)
                {
                    int matchCount = 0;

                    for (int i = 0; i < word.Length; i++)
                    {
                        int nx = x + dir.x * i;
                        int ny = y + dir.y * i;

                        if (nx < 0 || ny < 0 || nx >= gridSize || ny >= gridSize)
                            break;

                        if (grid[ny, nx].GetLetter() == word[i])
                            matchCount++;
                        else
                            break;
                    }

                    if (matchCount == word.Length)
                    {
                        for (int i = 0; i < word.Length; i++)
                        {
                            int nx = x + dir.x * i;
                            int ny = y + dir.y * i;
                            grid[ny, nx].Highlight(Color.cyan); // Hint color
                        }
                        return;
                    }
                }
            }
        }
    }

    private GridCell[,] GetGridFromManager()
    {
        var field = typeof(WordSearchManager).GetField("grid", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance);
        return field.GetValue(wordSearchManager) as GridCell[,];
    }
}
