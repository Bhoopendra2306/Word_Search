using UnityEngine;
using TMPro;

public class TimerManager : MonoBehaviour
{
    public float startTimeInSeconds = 180f; // 3 minutes
    public TMP_Text timerText;
    public GameObject gameOverPanel;

    private float currentTime;
    private bool isPaused = false;
    private bool isRunning = false;

    void Start()
    {
        currentTime = startTimeInSeconds;
        isRunning = true;
    }

    void Update()
    {
        if (!isRunning || isPaused) return;

        currentTime -= Time.deltaTime;
        UpdateTimerUI();

        if (currentTime <= 0)
        {
            isRunning = false;
            gameOverPanel.SetActive(true);
        }
    }

    void UpdateTimerUI()
    {
        int minutes = Mathf.FloorToInt(currentTime / 60);
        int seconds = Mathf.FloorToInt(currentTime % 60);
        timerText.text = $"{minutes:00}:{seconds:00}";
    }

    public void PauseTimer()
    {
        isPaused = true;
    }

    public void ResumeTimer()
    {
        isPaused = false;
    }

    public float GetRemainingTime()
    {
        return currentTime;
    }
}
