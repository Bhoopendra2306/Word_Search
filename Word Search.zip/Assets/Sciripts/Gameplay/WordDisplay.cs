using UnityEngine;
using TMPro;

public class WordDisplay : MonoBehaviour
{
    public string word;
    private TMP_Text text;

    public void Setup(string w)
    {
        word = w;
        text = GetComponent<TMP_Text>();
        text.text = w;
    }

    public void MarkFound()
    {
        if (text != null)
            text.color = Color.green;
    }
}
