using UnityEngine;
using TMPro;
using UnityEngine.UI;
using System.Collections.Generic;

public class GridCell : MonoBehaviour
{
    public TMP_Text letterText;
    private Image bgImage;

    private char letter = '\0';
    private List<string> wordMembership = new List<string>();
    public Vector2Int coordinates;

    void Awake()
    {
        bgImage = GetComponent<Image>();
    }

    public void SetLetter(char c)
    {
        letter = c;
        letterText.text = c.ToString();
    }

    public char GetLetter()
    {
        return letter;
    }

    public void AddToWord(string word)
    {
        if (!wordMembership.Contains(word))
        {
            wordMembership.Add(word);
        }
    }

    public void Highlight(Color color)
    {
        if (bgImage != null)
            bgImage.color = color;
    }

    public void SetCoordinates(int x, int y)
    {
        coordinates = new Vector2Int(x, y);
    }
}
