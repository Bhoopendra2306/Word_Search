using UnityEngine;
using UnityEngine.EventSystems;
using System.Collections.Generic;

public class SelectionManager : MonoBehaviour
{
    // List to keep track of the currently selected grid cells.
    private List<GridCell> selectedCells = new List<GridCell>();

    // Flag to know if the user is currently dragging.
    private bool isDragging = false;

    // Reference to our WordSearchManager, so we can get grid cells by coordinates.
    public WordSearchManager wordSearchManager;

    // List of colors to cycle through for valid words
    private List<Color> wordColors = new List<Color>
{
    Color.green,                                // Green
    new Color(1f, 0.5f, 0f),                    // Orange
    new Color(0.5f, 0f, 1f),                    // Purple
    new Color(1f, 0.4f, 0.7f),                  // Pink
    Color.cyan,                                 // Cyan
    new Color(1f, 1f, 0f),                      // Yellow
    new Color(0.5f, 1f, 0.5f),                  // Light Green
    new Color(1f, 0.7f, 0.3f),                  // Peach
    new Color(0.9f, 0.1f, 0.1f),                // Red
    new Color(0.8f, 0.0f, 0.5f),                // Magenta
    new Color(0.2f, 0.6f, 1f),                  // Cornflower Blue
    new Color(0.3f, 0.85f, 0.4f),               // Mint
    new Color(0.6f, 0.2f, 0.8f),                // Lavender
    new Color(1f, 0.85f, 0f)                    // Gold
};


    private int currentColorIndex = 0;

    // Update is called once per frame.
    void Update()
    {
        // When the user presses the left mouse button...
        if (Input.GetMouseButtonDown(0))
        {
            // Clear any previous cell selections.
            selectedCells.Clear();
            // Begin the dragging operation.
            isDragging = true;
        }

        // When the left mouse button is released...
        if (Input.GetMouseButtonUp(0))
        {
            // Stop dragging.
            isDragging = false;
            // Check if the currently selected cells form a valid word.
            CheckWord();
        }

        // If the user is dragging...
        if (isDragging)
        {
            // Get the current mouse position.
            Vector2 mousePos = Input.mousePosition;
            // Create pointer event data with the mouse position.
            PointerEventData pointerData = new PointerEventData(EventSystem.current);
            pointerData.position = mousePos;

            // Create a list to hold raycast results.
            List<RaycastResult> results = new List<RaycastResult>();
            // Raycast all UI elements under the mouse.
            EventSystem.current.RaycastAll(pointerData, results);

            // Hold a reference for the candidate cell that the mouse is over.
            GridCell candidateCell = null;
            // Loop through the raycast results.
            foreach (RaycastResult result in results)
            {
                // Try to get a GridCell component from the UI element.
                GridCell cell = result.gameObject.GetComponent<GridCell>();
                if (cell != null)
                {
                    // Use the first encountered grid cell as our candidate.
                    candidateCell = cell;
                    break;
                }
            }

            // If we got a grid cell from the raycast...
            if (candidateCell != null)
            {
                // If no cell has been selected yet, use the candidate as the anchor.
                if (selectedCells.Count == 0)
                {
                    selectedCells.Add(candidateCell);
                    candidateCell.Highlight(Color.yellow);
                }
                else
                {
                    // The first cell in the list is our anchor.
                    GridCell anchor = selectedCells[0];
                    // Compute the difference between the candidate and the anchor.
                    Vector2Int diff = candidateCell.coordinates - anchor.coordinates;
                    // If diff is zero, it means the candidate is the anchor; do nothing.
                    if (diff == Vector2Int.zero)
                        return;

                    // Determine the new selection direction by "snapping" to one of the 8 allowed directions.
                    // Use Mathf.Sign to get -1, 0, or 1 for each axis.
                    // Compute the differences from the anchor cell to the candidate.
                    int xDiff = candidateCell.coordinates.x - anchor.coordinates.x;
                    int yDiff = candidateCell.coordinates.y - anchor.coordinates.y;

                    // Determine the new direction by snapping to a straight line.
                    // This way, if the horizontal difference is greater,
                    // we force vertical component to zero, and vice versa.
                    Vector2Int newDirection;
                    if (Mathf.Abs(xDiff) > Mathf.Abs(yDiff))
                    {
                        // Horizontal dominant: select left/right only.
                        newDirection = new Vector2Int((int)Mathf.Sign(xDiff), 0);
                    }
                    else if (Mathf.Abs(yDiff) > Mathf.Abs(xDiff))
                    {
                        // Vertical dominant: select up/down only.
                        newDirection = new Vector2Int(0, (int)Mathf.Sign(yDiff));
                    }
                    else
                    {
                        // If they�re the same, then it�s a diagonal selection.
                        newDirection = new Vector2Int((int)Mathf.Sign(xDiff), (int)Mathf.Sign(yDiff));
                    }



                    // Calculate the number of steps we need to take. (The steps equals the maximum delta in x or y)
                    int steps = Mathf.Max(Mathf.Abs(diff.x), Mathf.Abs(diff.y));

                    // Build a new list that represents the straight line from the anchor in the new direction.
                    List<GridCell> newSelection = new List<GridCell>();
                    newSelection.Add(anchor);

                    // Loop through to add each cell in the straight line.
                    for (int i = 1; i <= steps; i++)
                    {
                        int newX = anchor.coordinates.x + newDirection.x * i;
                        int newY = anchor.coordinates.y + newDirection.y * i;
                        // Use the helper method from WordSearchManager to retrieve the cell by coordinates.
                        GridCell nextCell = wordSearchManager.GetCell(newX, newY);
                        // If a cell exists at these coordinates, add it.
                        if (nextCell != null)
                        {
                            newSelection.Add(nextCell);
                        }
                        else
                        {
                            // If we fall off the grid, stop adding cells.
                            break;
                        }
                    }

                    // Before updating the selection, remove the highlight from all previously selected cells.
                    foreach (var cell in selectedCells)
                    {
                        cell.Highlight(Color.white);
                    }

                    // Update the selectedCells list with the new line.
                    selectedCells = newSelection;
                    // Highlight the new selection in yellow.
                    foreach (var cell in selectedCells)
                    {
                        cell.Highlight(Color.yellow);
                    }
                }
            }
        }
    }

    // This function is called when dragging stops.
    // It forms a word from the letters in the selected cells and checks if it is valid.
    void CheckWord()
    {
        string formedWord = "";
        foreach (var cell in selectedCells)
        {
            formedWord += cell.GetLetter();
        }

        if (wordSearchManager.IsWordInList(formedWord))
        {
            // Get the next color in the list
            Color highlightColor = wordColors[currentColorIndex];
            currentColorIndex = (currentColorIndex + 1) % wordColors.Count;

            // Highlight selected cells with the current color
            foreach (var cell in selectedCells)
            {
                cell.Highlight(highlightColor);
            }

            wordSearchManager.WordFound(formedWord);
        }
        else
        {
            foreach (var cell in selectedCells)
            {
                cell.Highlight(Color.white);
            }
        }

        selectedCells.Clear();
    }

}
