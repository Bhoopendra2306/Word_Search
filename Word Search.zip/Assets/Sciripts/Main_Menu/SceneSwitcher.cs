using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SceneSwitcher : MonoBehaviour
{
    public GameObject loadingScreen;

    public void ChangeScene(string sceneName)
    {
        StartCoroutine(DelayedSceneChange(sceneName));
    }

    private IEnumerator DelayedSceneChange(string sceneName)
    {
        loadingScreen.SetActive(true);
        yield return new WaitForSeconds(1.5f);
        SceneManager.LoadScene(sceneName);
    }
}
